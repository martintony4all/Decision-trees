##################
# This is a combination of functions for pre-processing 
# the datasets used in ISQA 8720 project. 
# 
# Author: Group 1
##################

library(dplyr)

# this function prepares the titanic dataset for our course
# it converts some of the integer columns to factors, adds the NA as a level for the 'embarked' variable,
# and relevels the target variable such that the positive class is used correctly in classification
prepare_modeldata <- function(modeldata, target_variable = 'churned', positive_class = '1'){
  
  # convert variables into factors
  modeldata <- modeldata %>% mutate_at(c('churned', 'HQ_Country','NAICS2', 'NAICS3'), as.factor)
  modeldata <- modeldata %>% mutate_if(is.character, as.factor)
  
  # then, we convert the 0/1 target variable into no/yes, as 0/1 can lead to problems when using as the dependent variable
  modeldata <- modeldata %>% mutate(churned, churned = recode(churned, '0' = 'No', '1' = 'Yes'))
  
  # add the NA as factor level to all factor variables
  modeldata <- modeldata %>% mutate_if(~ any(is.na(.)), addNA)
  
  return(modeldata)
}



prepare_modeldata_numeric <-function(modeldata_numeric, target_variable = 'churned', positive_class = '1'){
  
  # convert variables into factors
  modeldata_numeric <- modeldata_numeric %>% mutate_at(c('churned'), as.factor)
  modeldata_numeric <- modeldata_numeric %>% mutate_if(is.character, as.factor)
  
  # then, we convert the 0/1 target variable into no/yes, as 0/1 can lead to problems when using as the dependent variable
  modeldata_numeric <- modeldata_numeric %>% mutate(churned, churned = recode(churned, '0' = 'No', '1' = 'Yes'))
  
  # add the NA as factor level to all factor variables
  modeldata_numeric <- modeldata_numeric %>% mutate_if(~ any(is.na(.)), addNA)
  
  return(modeldata_numeric)
}

prepare_modeldata_M <-function(modeldata_numeric, target_variable = 'Manufacturing_Indicator', positive_class = '0'){
  
  # convert variables into factors
  modeldata_numeric <- modeldata_numeric %>% mutate_at(c('Manufacturing_Indicator'), as.factor)
  modeldata_numeric <- modeldata_numeric %>% mutate_if(is.character, as.factor)
  
  # then, we convert the 0/1 target variable into no/yes, as 0/1 can lead to problems when using as the dependent variable
  modeldata_numeric <- modeldata_numeric %>% mutate(Manufacturing_Indicator, Manufacturing_Indicator = recode(Manufacturing_Indicator, '1' = 'No', '0' = 'Yes'))
  
  # add the NA as factor level to all factor variables
  modeldata_numeric <- modeldata_numeric %>% mutate_if(~ any(is.na(.)), addNA)
  
  return(modeldata_numeric)
}

prepare_modeldata_O <-function(modeldata_numeric, target_variable = 'Owns_Rents_Code', positive_class = '1'){
  
  # convert variables into factors
  modeldata_numeric <- modeldata_numeric %>% mutate_at(c('Owns_Rents_Code'), as.factor)
  modeldata_numeric <- modeldata_numeric %>% mutate_if(is.character, as.factor)
  
  # then, we convert the 0/1 target variable into no/yes, as 0/1 can lead to problems when using as the dependent variable
  modeldata_numeric <- modeldata_numeric %>% mutate(Owns_Rents_Code, Owns_Rents_Code = recode(Owns_Rents_Code, '0' = 'UNKNOWN', '1' = 'YES', '2' = 'NO'))
  
  # add the NA as factor level to all factor variables
  modeldata_numeric <- modeldata_numeric %>% mutate_if(~ any(is.na(.)), addNA)
  
  return(modeldata_numeric)
}

prepare_modeldata_S <-function(modeldata_numeric, target_variable = 'Status_Code', positive_class = '1'){
  
  # convert variables into factors
  modeldata_numeric <- modeldata_numeric %>% mutate_at(c('Status_Code'), as.factor)
  modeldata_numeric <- modeldata_numeric %>% mutate_if(is.character, as.factor)
  
  # then, we convert the 0/1 target variable into no/yes, as 0/1 can lead to problems when using as the dependent variable
  modeldata_numeric <- modeldata_numeric %>% mutate(Status_Code, Status_Code = recode(Status_Code, '0' = 'SINGLE', '1' = 'HeadQuater', '2' = 'BRANCH'))
  
  # add the NA as factor level to all factor variables
  modeldata_numeric <- modeldata_numeric %>% mutate_if(~ any(is.na(.)), addNA)
  
  return(modeldata_numeric)
}

