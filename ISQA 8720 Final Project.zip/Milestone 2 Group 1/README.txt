README

1. The folder �Data� contains the training (final_model.csv) and test (final_test.csv) files used for the project

2. The csv file �Churn_predictionxgb� contains best churn predictions given by gradient boosting.

3. The csv file �Date_predictionridge� contains date predictions with the smallest RMSE given by ridge 
   regression.

4. The R file "Modelling Group2" contains codes for data preparation and classification methods for churn 
   prediction.

5. The R file "Modelling regression" contains codes for data preparation and regression methods for predicting 
   chrun date.

6. The R file "UtilsP" contains codes for data preparation 

7. The csv file "Final_modeldata_churned" contains the final_model data along with the calculated date.
   Here 'date' is computed as the difference between the company_creation_date and the churned_date

8. The folder "Computing probs" contains predictions and probabilities for selected model (gradient bosting) 
    applying SMOTE(upscaling) but without splitting the training data.